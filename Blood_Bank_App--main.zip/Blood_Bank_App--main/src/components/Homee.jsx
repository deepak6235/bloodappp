import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';

export default function ActionAreaCard() {
  return (
    <Card fullWidth>
      <CardActionArea>
        <CardMedia
          component="img"
          height="140"
          image="C:\Users\lenovo\Desktop\BloddApp\bloodapp\public\blood.png"
          alt="green iguana"
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            Blood Donation
          </Typography>
          <Typography variant="body2" color="text.secondary">
          A single drop of your blood could be a drop of life for someone else.
          </Typography>
        </CardContent>
      </CardActionArea>
    </Card>
  );
}