import { Button, FormControl, FormControlLabel, Radio, RadioGroup, TextField, Typography } from '@mui/material'
import React from 'react'

const Sign = () => {
  return (
    <div style={{paddingTop:"80px"}}>

<Typography variant="h5">
        <b>Welcome to SignUp Page</b>
        </Typography><br></br><br></br>

        <TextField id="outlined-basic" label="First Name" variant="outlined"/><br ></br><br></br>
        <TextField id="outlined-basic" label="Last name" variant="outlined" /><br></br><br></br>
        <TextField id="outlined-basic" label="Email" variant="outlined" /><br></br><br></br>
        <TextField id="outlined-basic" label="Password" variant="outlined" /><br></br><br></br>
        <TextField id="outlined-basic" label="Confirm password" variant="outlined" /><br></br><br></br>
        <FormControl>
        <h3>Gender</h3><br></br>
   
      <RadioGroup
        row
        aria-labelledby="demo-row-radio-buttons-group-label"
        name="row-radio-buttons-group"
      >
        <FormControlLabel value="female" control={<Radio />} label="Female" />
        <FormControlLabel value="male" control={<Radio />} label="Male" />
        <FormControlLabel value="other" control={<Radio />} label="Other" />
        
      </RadioGroup>
    </FormControl><br></br><br></br>
        <Button variant="contained" color="success">
  Create Account
</Button>
    </div>
  )
}

export default Sign